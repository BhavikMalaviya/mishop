import 'package:micatalogs/controllers/base_controller.dart';

class ViewBusinessDetailsController extends BaseController {
}
