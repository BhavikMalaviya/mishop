

import 'package:micatalogs/controllers/base_controller.dart';

class AddEditCategoryController extends BaseController {
  String title;
}