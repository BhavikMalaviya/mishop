import 'package:micatalogs/controllers/base_controller.dart';

class CategoryActionController extends BaseController {
}
