import 'package:micatalogs/controllers/base_controller.dart';

class CategoryProductController extends BaseController {
  int currentTabIndex = 0;
  bool isSwitched = false;
}
