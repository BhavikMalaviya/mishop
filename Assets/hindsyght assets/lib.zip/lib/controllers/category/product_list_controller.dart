import 'package:micatalogs/controllers/base_controller.dart';

class ProductListController extends BaseController {
  bool isSwitched = true;
}
