import 'package:micatalogs/controllers/base_controller.dart';

class DashboardController extends BaseController {}
