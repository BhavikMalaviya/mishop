import 'package:micatalogs/controllers/base_controller.dart';

class ProfileScreenController extends BaseController {
  
}
