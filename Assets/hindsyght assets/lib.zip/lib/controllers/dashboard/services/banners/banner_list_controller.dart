import 'package:micatalogs/controllers/base_controller.dart';

class BannerListController extends BaseController {}
