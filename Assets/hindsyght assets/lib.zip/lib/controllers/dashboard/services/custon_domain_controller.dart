import 'package:micatalogs/controllers/base_controller.dart';

class CustomDomainController extends BaseController {
  String domainName;
  String extraNote;
}