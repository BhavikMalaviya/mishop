import 'package:micatalogs/controllers/base_controller.dart';

class SettingController extends BaseController {
  String chargePerOrder;
  String freeDeliveryAbove;
  String facebookPixelKey;
  String googleAnalyticsKey;
}
