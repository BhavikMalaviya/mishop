import 'package:micatalogs/controllers/base_controller.dart';

class AddEditProductController extends BaseController {
  String title;
  String description;
}