class AppData {
  // App Name
  static const String appName = 'MiCatalogs';
  static const String apiBaseUrl = 'http://api.aeonarc.in/api/v1/';
  static const Map noInternetJson = {"message": "No Internet Connection"};
}
